<?php
session_start();

// Security check
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.html");
    exit;
}

include_once('../php/connt.php');

// Initialize variables
$errorMsg = '';
$successMsg = '';

// Check if the employee ID is present
if (isset($_GET['id'])) {
    $employeeId = intval($_GET['id']);

    // Fetch employee details on GET request
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $stmt = $conn->prepare("SELECT EmployeeID, FirstName, LastName, Email, PhoneNumber FROM Employees WHERE EmployeeID = ?");
        $stmt->bind_param("i", $employeeId);
        $stmt->execute();
        $result = $stmt->get_result();
        $employee = $result->fetch_assoc();
    }

    // Update employee details on POST request
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $email = $_POST['email'];
        $phoneNumber = $_POST['phoneNumber'];

        if (empty($firstName) || empty($lastName) || empty($email) || empty($phoneNumber)) {
            $errorMsg = "All fields are required.";
        } else {
            $updateStmt = $conn->prepare("UPDATE Employees SET FirstName = ?, LastName = ?, Email = ?, PhoneNumber = ? WHERE EmployeeID = ?");
            $updateStmt->bind_param("ssssi", $firstName, $lastName, $email, $phoneNumber, $employeeId);
            $updateStmt->execute();

            if ($updateStmt->affected_rows > 0) {
                echo "<script>alert('User updated successfully'); window.location = 'manage_employees.php';</script>";
            } else {
                echo "<script>alert('No changes were made or update failed');</script>";
            }
        }
    }
} else {
    header("Location: manage_employees.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #d7c7ae;
    margin: 0;
    padding: 20px;
    color: #8a6d46;
}
form {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    width: 300px; /* Adjust width as needed */
    margin: 20px auto;
}
label {
    display: block;
    margin: 15px 0 5px;
}
input[type="text"], input[type="email"], input[type="tel"] {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
}
button {
    width: 100%;
    padding: 10px;
    background-color: #8a6d46;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-top: 20px;
}
button:hover {
    background-color: #7a5d3e;
}
.error-msg, .success-msg {
    color: red;
    font-weight: bold;
    text-align: center;
    margin: 10px 0;
}
.success-msg {
    color: green;
}

    </style>
    <link rel="stylesheet" href="styles.css"> <!-- Assume you have a styles.css file for consistent styling -->
</head>
<body>
    <h1>Edit Employee</h1>
    <?php if ($errorMsg) echo "<p style='color:red;'>$errorMsg</p>"; ?>
    <?php if ($successMsg) echo "<p style='color:green;'>$successMsg</p>"; ?>

    <form action="edit_employee.php?id=<?php echo $employeeId; ?>" method="post">
        <label for="firstName">First Name:</label>
        <input type="text" id="firstName" name="firstName" value="<?php echo htmlspecialchars($employee['FirstName']); ?>" required>

        <label for="lastName">Last Name:</label>
        <input type="text" id="lastName" name="lastName" value="<?php echo htmlspecialchars($employee['LastName']); ?>" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($employee['Email']); ?>" required>

        <label for="phoneNumber">Phone Number:</label>
        <input type="text" id="phoneNumber" name="phoneNumber" value="<?php echo htmlspecialchars($employee['PhoneNumber']); ?>" required>

        <button type="submit">Update Employee</button>
    </form>
</body>
</html>
