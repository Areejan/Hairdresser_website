<?php
session_start();
include_once('../php/connt.php'); 
$email = $_POST['email'];
$password = $_POST['password'];

// Database query
$sql = "SELECT id FROM admins WHERE email = ? AND password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    // Successful login
    $admin = $result->fetch_assoc();
    $_SESSION['admin_id'] = $admin['id'];
    header("Location: index.php"); // Redirect to an admin dashboard page
} else {
    // Failed login
    header("Location: admin_login.php"); // Redirect back to the login page if failed
    exit;
}
?>
