<?php
session_start();

// Security check
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include_once('../php/connt.php');

// Initialize an error message variable
$errorMsg = '';

// Check if the appointment ID is present
if (isset($_GET['id'])) {
    $appointmentId = intval($_GET['id']);

    // Fetch appointment details
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        // Fetch the main appointment details
        $stmt = $conn->prepare("SELECT AppointmentTime, Branch FROM appointments WHERE AppointmentID = ?");
        $stmt->bind_param("i", $appointmentId);
        $stmt->execute();
        $result = $stmt->get_result();
        $appointment = $result->fetch_assoc();

        // Fetch the services associated with this appointment
        $servicesStmt = $conn->prepare("SELECT ServiceID FROM appointmentservices WHERE AppointmentID = ?");
        $servicesStmt->bind_param("i", $appointmentId);
        $servicesStmt->execute();
        $servicesResult = $servicesStmt->get_result();
        $selectedServices = [];
        while ($service = $servicesResult->fetch_assoc()) {
            $selectedServices[] = $service['ServiceID'];
        }
    }

    // Handle POST request to update the appointment details
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $appointmentTime = $_POST['appointmentTime'];
        $branch = $_POST['branch'];
        $services = $_POST['services'] ?? [];

        // Begin transaction
        $conn->begin_transaction();

        try {
            // Update the main appointment details
            $updateStmt = $conn->prepare("UPDATE appointments SET AppointmentTime = ?, Branch = ? WHERE AppointmentID = ?");
            $updateStmt->bind_param("ssi", $appointmentTime, $branch, $appointmentId);
            $updateStmt->execute();

            // Update the services
            $deleteServicesStmt = $conn->prepare("DELETE FROM appointmentservices WHERE AppointmentID = ?");
            $deleteServicesStmt->bind_param("i", $appointmentId);
            $deleteServicesStmt->execute();

            $insertServiceStmt = $conn->prepare("INSERT INTO appointmentservices (AppointmentID, ServiceID) VALUES (?, ?)");
            foreach ($services as $serviceId) {
                $insertServiceStmt->bind_param("ii", $appointmentId, $serviceId);
                $insertServiceStmt->execute();
            }

            // Commit transaction
            $conn->commit();
            header("Location: manage_appointments.php");
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $errorMsg = "Error updating appointment: " . $e->getMessage();
        }
    }
} else {
    // Redirect back if no appointment ID
    header("Location: manage_appointments.php");
    exit;
}

// Fetch all possible services to display in the form
$allServicesQuery = "SELECT ServesID, Name FROM serves";
$allServicesResult = $conn->query($allServicesQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #d7c7ae;
            margin: 0;
            padding: 20px;
            color: #8a6d46;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            width: 95%; 
            margin: auto;
        }
        label {
            display: block;
            margin: 15px 0 5px;
        }
        input[type="datetime-local"], select, input[type="checkbox"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #8a6d46;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 20px;
        }
        button:hover {
            background-color: #7a5d3e;
        }
        fieldset {
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 10px;
        }
        legend {
            padding: 0 10px;
            color: #8a6d46;
        }
        .error-msg {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Edit Appointment</h1>
    <?php if ($errorMsg) echo "<p class='error-msg'>$errorMsg</p>"; ?>
    <form method="POST">
        <label for="appointmentTime">Appointment Time:</label>
        <input type="datetime-local" id="appointmentTime" name="appointmentTime" value="<?php echo date('Y-m-d\TH:i', strtotime($appointment['AppointmentTime'])); ?>" required>

        <label for="branch">Branch:</label>
        <select id="branch" name="branch">
            <option value="Burydah" <?php echo $appointment['Branch'] == 'Burydah' ? 'selected' : ''; ?>>Burydah</option>
            <option value="Unaizah" <?php echo $appointment['Branch'] == 'Unaizah' ? 'selected' : ''; ?>>Unaizah</option>
            <option value="Alrrass" <?php echo $appointment['Branch'] == 'Alrrass' ? 'selected' : ''; ?>>Alrrass</option>
        </select>

        <fieldset>
            <legend>Select Services:</legend>
            <?php
            while ($service = $allServicesResult->fetch_assoc()) {
                $checked = in_array($service['ServesID'], $selectedServices) ? 'checked' : '';
                echo "<label><input type='checkbox' name='services[]' value='{$service['ServesID']}' $checked> {$service['Name']}</label><br>";
            }
            ?>
        </fieldset>

        <button type="submit">Update Appointment</button>
    </form>
</body>
</html>

