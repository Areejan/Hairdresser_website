<?php
session_start();

// Security check
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Include the database connection
include_once('../php/connt.php');

// Fetch all appointments from the database
$query = "SELECT a.AppointmentID, c.CustomerID, c.CFName, c.CLName, a.AppointmentTime, a.Branch, GROUP_CONCAT(s.Name SEPARATOR ', ') AS Services
FROM appointments a
JOIN customer c ON a.CustomerID = c.CustomerID
JOIN appointmentservices asv ON a.AppointmentID = asv.AppointmentID
JOIN serves s ON asv.ServiceID = s.ServesID
GROUP BY a.AppointmentID";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Appointments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #d7c7ae;
            margin: 0;
            padding: 20px;
            color: #8a6d46;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #8a6d46;
            color: white;
        }
        a {
            color: #8a6d46;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <a href="index.php">Back</a>
    <h1>Manage Appointments</h1>
    <table>
        <thead>
            <tr>
                <th>Appointment ID</th>
                <th>Customer Name</th>
                <th>Services</th>
                <th>Appointment Time</th>
                <th>Branch</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['AppointmentID']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['CFName']) . ' ' . htmlspecialchars($row['CLName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Services']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['AppointmentTime']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Branch']) . "</td>";
                    echo "<td><a href='edit_appointment.php?id=" . $row['AppointmentID'] . "'>Edit</a> | <a href='delete_appointment.php?id=" . $row['AppointmentID'] . "' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No appointments found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
