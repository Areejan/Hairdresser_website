<?php
session_start();

// Check if the admin is logged in, else redirect to login page
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Include the database connection file
include_once('../php/connt.php'); 

// Additional PHP code for handling other functionalities can go here
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #d7c7ae;
            margin: 0;
            padding: 20px;
            color: #8a6d46;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
        }
        .module {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            margin: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            width: calc(33% - 20px);
            text-align: center;
        }
        a {
            color: #8a6d46;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        h1 {
            color: #8a6d46;
        }
    </style>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <div class="dashboard">
        <div class="module">
            <a href="manage_users.php">
                <h2>Manage Users</h2>
                <p>Go to User Management</p>
            </a>
        </div>
        <div class="module">
            <a href="manage_appointments.php">
                <h2>Manage Appointments</h2>
                <p>Go to Appointments Management</p>
            </a>
        </div>
        <div class="module">
            <a href="manage_employees.php">
                <h2>Manage Employees</h2>
                <p>Go to Employees Management</p>
            </a>
        </div>
        <div class="module">
            <a href="logout.php">
                <h2>Logout</h2>
                <p>Log Out</p>
            </a>
        </div>
    </div>
</body>
</html>
