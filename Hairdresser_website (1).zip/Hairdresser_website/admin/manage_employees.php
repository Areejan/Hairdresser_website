<?php
session_start();

// Security check
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.html");
    exit;
}

// Include the database connection
include_once('../php/connt.php');

// Fetch all employees from the database
$query = "SELECT EmployeeID, FirstName, LastName, Email, PhoneNumber FROM Employees";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Employees</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #d7c7ae;
            margin: 0;
            padding: 20px;
            color: #8a6d46;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #8a6d46;
            color: white;
        }
        a {
            color: #8a6d46;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <a href="index.php">Back</a>
    <h1>Manage Employees</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['EmployeeID']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['FirstName']) . " " . htmlspecialchars($row['LastName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Email']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['PhoneNumber']) . "</td>";
                    echo "<td><a href='edit_employee.php?id=" . $row['EmployeeID'] . "'>Edit</a> </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No employees found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
