<?php
session_start();

// Security check
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include_once('../php/connt.php');

// Check if the user ID is present
if (isset($_GET['id'])) {
    $userId = intval($_GET['id']);

    // Fetch user data
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $stmt = $conn->prepare("SELECT CustomerID, CFName, CLName, CEmail, CPhone FROM Customer WHERE CustomerID = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
    }

    // Process the update
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $cfname = $conn->real_escape_string($_POST['cfname']);
        $clname = $conn->real_escape_string($_POST['clname']);
        $cemail = $conn->real_escape_string($_POST['cemail']);
        $cphone = $conn->real_escape_string($_POST['cphone']);

        $updateStmt = $conn->prepare("UPDATE Customer SET CFName = ?, CLName = ?, CEmail = ?, CPhone = ? WHERE CustomerID = ?");
        $updateStmt->bind_param("ssssi", $cfname, $clname, $cemail, $cphone, $userId);
        $updateStmt->execute();

        if ($updateStmt->affected_rows > 0) {
            echo "<script>alert('User updated successfully'); window.location = 'manage_users.php';</script>";
        } else {
            echo "<script>alert('No changes were made or update failed');</script>";
        }
    }
} else {
    // Redirect back if no user ID
    header("Location: manage_users.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #d7c7ae;
            margin: 0;
            padding: 20px;
            color: #8a6d46;
        }
        input[type="text"], input[type="email"], input[type="tel"] {
            width: 100%;
            padding: 8px;
            margin-top: 8px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #8a6d46;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Edit User</h1>
    <form method="POST">
        <label for="cfname">First Name:</label>
        <input type="text" id="cfname" name="cfname" value="<?php echo htmlspecialchars($user['CFName']); ?>" required>

        <label for="clname">Last Name:</label>
        <input type="text" id="clname" name="clname" value="<?php echo htmlspecialchars($user['CLName']); ?>" required>

        <label for="cemail">Email:</label>
        <input type="email" id="cemail" name="cemail" value="<?php echo htmlspecialchars($user['CEmail']); ?>" required>

        <label for="cphone">Phone:</label>
        <input type="tel" id="cphone" name="cphone" value="<?php echo htmlspecialchars($user['CPhone']); ?>" required>

        <input type="submit" value="Update User">
    </form>
</body>
</html>
