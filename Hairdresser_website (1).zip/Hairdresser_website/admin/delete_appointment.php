<?php
session_start();

// Security check
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include_once('../php/connt.php');

// Check if the appointment ID is present
if (isset($_GET['id'])) {
    $appointmentId = intval($_GET['id']);

    // Start transaction
    $conn->begin_transaction();

    try {
        // First, delete any associated services in appointmentservices
        $deleteServicesStmt = $conn->prepare("DELETE FROM appointmentservices WHERE AppointmentID = ?");
        $deleteServicesStmt->bind_param("i", $appointmentId);
        $deleteServicesStmt->execute();

        // Then delete the appointment itself
        $deleteAppointmentStmt = $conn->prepare("DELETE FROM appointments WHERE AppointmentID = ?");
        $deleteAppointmentStmt->bind_param("i", $appointmentId);
        $deleteAppointmentStmt->execute();

        // Commit the transaction
        $conn->commit();

        if ($deleteAppointmentStmt->affected_rows > 0) {
            $_SESSION['message'] = "Appointment deleted successfully.";
        } else {
            $_SESSION['message'] = "Error deleting appointment or appointment not found.";
        }
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['message'] = "Error: " . $e->getMessage();
    }

    $deleteServicesStmt->close();
    $deleteAppointmentStmt->close();
    $conn->close();

    // Redirect back to the manage appointments page
    header("Location: manage_appointments.php");
    exit;
} else {
    // Redirect back if no appointment ID
    header("Location: manage_appointments.php");
    exit;
}
?>
