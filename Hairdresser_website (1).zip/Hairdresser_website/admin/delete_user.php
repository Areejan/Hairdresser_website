<?php
session_start();

// Security check
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include_once('../php/connt.php');

// Check if the user ID is present
if (isset($_GET['id'])) {
    $userId = intval($_GET['id']);

    // Prepare and execute the deletion query
    $stmt = $conn->prepare("DELETE FROM Customer WHERE CustomerID = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();

    // Check if the deletion was successful
    if ($stmt->affected_rows > 0) {
        $_SESSION['message'] = "User deleted successfully.";
    } else {
        $_SESSION['message'] = "Error deleting user or user not found.";
    }

    $stmt->close();
    $conn->close();

    // Redirect back to the manage users page
    header("Location: manage_users.php");
    exit;
} else {
    // Redirect back if no user ID
    header("Location: manage_users.php");
    exit;
}
?>
