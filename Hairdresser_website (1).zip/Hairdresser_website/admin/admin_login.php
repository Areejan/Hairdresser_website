<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #d7c7ae;
        }
        .login-form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .form-control {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .login-button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #8a6d46;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        .login-button:hover {
            background-color: #7a5d3e;
        }
    </style>
</head>
<body>
    <div class="login-form">
        <form action="admin_login_processor.php" method="POST">
            <h2 style="color: #8a6d46; text-align: center;">Admin Login</h2>
            <!-- Email input -->
            <input type="txt" name="email" class="form-control" placeholder="Username" required>
            <!-- Password input -->
            <input type="password" name="password" class="form-control" placeholder="Password" required>
            <!-- Submit button -->
            <button type="submit" class="login-button">Login</button>
        </form>
    </div>
</body>
</html>
