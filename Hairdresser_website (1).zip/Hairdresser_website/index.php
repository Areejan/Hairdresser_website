<?php
session_start(); // Start the session

// Check if the user is logged in, using the 'email' session variable
if (!isset($_SESSION['email'])) {
    header("Location: login.html");
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHIC SALON</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- header -->
    <section class="header">

        <a href="#" class="logo"> CHIC SALON </a>
     
        <a href="#" class="logo">صالون شيك</a>
        <nav class="navbar">
            <div id="close-navbar" class="fas fa-time"></div>
            <a href="#home">الرئيسية</a>
            <a href="php/logout.php">تسجيل الخروج</a>
            <a href="#about">عنا</a>
            <a href="#services">خدماتنا</a>
            <a href="#Visit">احجز الآن</a>
            <a href="#review">ارائكم عنا</a>
            <a href="#footer">تواصلوا معنا</a>
            
        </nav>
     
        <div id="menu-btn" class="fas fa-bars"></div>
     
     </section>
<!-- header -->

<!-- home -->

<section class="home" id="home">

    <div class="content">
        <span>أهلا بكم في شيك صالون</span>  
        <h3>أهتمامنا الأول جمالك</h3>
    </div>
</section>
<!-- home -->
    <section>
<!-- <body>
    <div class="container">
        <h1 class="heading">تسجيل دخول </h1>
        <form action="Sign.php" method="post">
            
            <label for="Fname"> أسمك</label>
            <input type="text" id="Fname" name="Fname" required>
            
            <label for="name">العائلة</label>
            <input type="text" id="Lname" name="Lname" required>

            <label for="email">الإيميل</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">رقم الجوال</label>
            <input type="tel" id="phone" name="phone" placeholder="05********" required>
            

            <label for="dob">تاريخ الميلاد</label>
            <input type="date" id="dob" name="dob" required>

            <label for="password">الرقم السري</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="تسجيل ">
        </form>
        <p>لديكِ حساب بالفعل؟ <a href="login.html">سجلي هنا</a>.</p>
        
    </div>
</body> -->
</section>
<!-- about us -->

<section class="about" id="about">

    <h1 class="heading">عنا</h1>

    <div class="row" >

        <div class="image">
            <img src="images/about.jpg" alt="">
        </div>

        <div class="content">
            <h3> رؤيتنا </h3>
            <p>تقديم خدمات احترافية من خلال اخصائيات ذوات كفاءة عالية باستخدام منتجات عالية الجودة</p>
            <h3> رسالتنا </h3>
            <p>لـخدمة جمالك في جميع انحاء المملكة العربية السعودية</p> 
            <div class="icons-container">
                <div class="icons">
                   <img src="images/about-icon-1.png" alt="">
                   <h3>أدوات إحترافية</h3>
                </div>
                <div class="icons">
                   <img src="images/about-icon-2.png" alt="">
                   <h3>منتجات ذات جودة عالية</h3>
                </div>
                <div class="icons">
                   <img src="images/about-icon-3.png" alt="">
                   <h3>غسيل الشعر</h3>
                </div>
             </div>
        </div>

    </div>

</section>

<!-- about us end -->

<!--Branch-->
<section class="Branch">
<body>
    <h1 class="heading">فروع صالون شيك</h1>
   
    <ul>
      <li>
        <a href="branch1.html">فرع عنيزة </a>
      </li>
      <li>
        <a href="branch2.html">فرع بريدة </a>
      </li>
      <li>
        <a href="branch3.html">فرع الرس </a>
      </li>
    </ul>
  </body>
</section>

  <!--Branch end-->
 <section class="services section" id="services">
            <div class="services__content">
                <div class="row">
                    <div class="section__title">
                        <h1 class="heading">خدمات صالون شيك </h1>
                        <!-- <h1>Services</h1>
                        <span>CHIC Salon</span>-->
                    </div>
                </div>
                <div class="services__content__descripion grid container">
                    <a href="Nails.html">
                        <div class="box">
                            <div class="inner">
                                <img src="im/manicure.png" alt="">
                                <p>منيكير</p>
                            </div>
                        </div>
                    </a>
                    <a href="Nails.html">

                    <div class="box">
                        <div class="inner">
                            <img src="im/pedicure.png" alt="">
                            <p>بديكير</p>
                        </div>
                    </div>
                    </a>
                    <a href="Makeup.html">
                    <div class="box">
                        <div class="inner">
                            <img src="im/maquiagem.png" alt="">
                            <p>ميك آب</p>
                        </div>
                    </div>
                    </a>
                    <a href="Hair.html">
                    <div class="box">
                        <div class="inner">
                            <img src="im/pentado.png" alt="">
                            <p>تسريحات الشعر</p>
                        </div>
                    </div>
                    </a>
                    <a href="Haircut.html">
                    <div class="box">
                        <div class="inner">
                            <img src="im/corte.png" alt="">
                            <p>قصات الشعر</p>
                        </div>
                    </div>
                    </a>
                    <a href="eyebrow.html">
                    <div class="box">
                        <div class="inner">
                            <img src="im/sobrancelha.png">
                            <p>الحواجب</p>
                        </div>
                    </div>
                    </a>
                    <a href="Faceandbody.html">
                    <div class="box">
                        <div class="inner">
                            <img src="im/depilacao.png" alt="">
                            <p>إزالة الشعر</p>
                        </div>
                    </div>
                    </a>
                    <a href="Relaxation.html">
                    <div class="box">
                        <div class="inner">
                            <img src="im/limpeza.png" alt="">
                            <p>تنظيف البشرة </p>
                        </div>
                    </div>
                    </a>
                </div>
            </div>
        </section>


<!-- styles -->

<section class="styles" id="styles">

    <h1 class="heading">اختاري تسريحتك</h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="images/style-1.jpg" alt="">
            </div>
            <div class="content">
                <h3 class="title">تسريحات شعر زواج</h3>
                <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p> -->
            </div>
         </div>
 
         <div class="box">
            <div class="image">
                <img src="images/style-2.jpg" alt="">
            </div>
            <div class="content">
                <h3 class="title">تسريحات شعر حفلة</h3>
              <!--  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p> -->
            </div>
         </div>
 
         <div class="box">
            <div class="image">
                <img src="images/style-3.jpg" alt="">
            </div>
            <div class="content">
                <h3 class="title"> تسريحات شعر يومية</h3>
              <!--<p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p> -->
            </div>
         </div>
 
         <div class="box">
             <div class="image">
                 <img src="images/style-4.jpg" alt="">
             </div>
             <div class="content">
                 <h3 class="title"> تسريحات شعر عمل</h3>
                 <!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p> -->

             </div>
         </div>

    </div>

</section>

<!-- styles end-->


<!-- pricing -->

<section class="pricing" id="pricing">

    <h1 class="heading">العروض</h1>

    <div class="box-container">

        <div class="box">
          <h3 class="title">بكج الجمال</h3>
          <div class="price">
            <span class="currency">ريال</span>
            <span class="amount">200</span>
          </div>
          <ul>
            <li> <i class="fas fa-check"></i> قص اطراف </li>
            <li> <i class="fas fa-check"></i> غسل شعر</li>
            <li> <i class="fas fa-check"></i> مناكير اكسبرس</li>
           
          </ul>
          <a href="#"><button>أحجزي الآن</button></a>
        </div>
        
        <div class="box">
          <h3 class="title">بكج المناسبات</h3>
          <div class="price">
            <span class="currency">ريال</span>
            <span class="amount">480</span>
          </div>
          <ul>
            <li> <i class="fas fa-check"></i> تسريحة</li>
            <li> <i class="fas fa-check"></i> قص اطراف </li>
            <li> <i class="fas fa-check"></i> صبغ خصلات</li>
       
          </ul>
          <a href="#"><button>أحجزي الآن</button></a>
        </div>
        
        <div class="box">
          <h3 class="title">بكج العروس</h3>
          <div class="price">
            <span class="currency">ريال</span>
            <span class="amount">1200</span>
          </div>
          <ul>
            <li> <i class="fas fa-check"></i>مساج شيك </li>
            <li> <i class="fas fa-check"></i>تسريحة شعر </li>
            <li> <i class="fas fa-check"></i>مناكير اند بدكير شيك </li>
          </ul>
          <a href="#"><button>أحجزي الآن</button></a>
        </div>
        
    </div>
    
</section>

<!-- pricing end -->


<!-- blog -->

<section class="blogs" id="blog">

    <h1 class="heading"> our blogs </h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="images/blog1.jpg" alt="">
            </div>
            <div class="content">
                <a href="#" class="title">Styling hair service</a>
                <span>by admin / 19th july, 2021</span>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Hic aut eligendi, doloremque nihil sapiente fugit aliquam? Error nisi velit, a atque fugit laborum.</p>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/blog2.jpg" alt="">
            </div>
            <div class="content">
                <a href="#" class="title">Styling hair service</a>
                <span>by admin / 19th july, 2021</span>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Hic aut eligendi, doloremque nihil sapiente fugit aliquam? Error nisi velit, a atque fugit laborum.</p>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/blog3.jpg" alt="">
            </div>
            <div class="content">
                <a href="#" class="title">Styling hair service</a>
                <span>by admin / 19th july, 2021</span>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Hic aut eligendi, doloremque nihil sapiente fugit aliquam? Error nisi velit, a atque fugit laborum.</p>
                
            </div>
        </div>

    </div>

</section>

<!-- blog end-->

<!-- visit -->

<section class="Visit" id="Visit">
    <!-- <h1 class="heading"> أحجزي موعدك الآن </h1>
        <div class="row">
           <form action="Book.php" method="post">
                <h3> Book Your Visit Today </h3>
                <div class="inputBox
                    <input type="text" placeholder="الإسم الكامل">  
                </div>
                <div class="inputBox">
                    <input type="text" placeholder="الإيميل">  
                </div>
                <div class="inputBox">
                    <input type="text" placeholder="رسالة">  
                </div>
                <div class="inputBox">
                    <input type="submit" placeholder="قم بالإرسال" class="btn"> 
                    </div>
            
            <div class="image">
                <img src="content.png" alt="">  Not added 
            </div>
            -->
    </section>
<!-- visit end-->

<!-- reviews -->

<section class="review" id="review">

    <h1 class="heading">اراء العملاء</h1>

    <div class="box-container">

        <div class="box">
            <img src="images/quote-img.png" alt="" class="quote">
            <p>أفضل صالون من كل النواحي
                جودة وخدمة وشغل يفتح النفس مرره
                جربت المنيكير والقص وتنظيف البشرة وكلهم واو وطلعت منهم راضيه ومبسوطه
                الضيافة وخدمة الاستقبال جداً لطيفه وتخليك تكرر الزيارة مرات كثير
                الاسعار معقولة على الجودة اللي يقدمونها لكن لو ينزلونها شوي يكون أفضل أو لو يكون فيه خصم خاص للعميل
                تصميم الصالون ووفرة الخدمات فيه ١٠/١٠
                .</p>
            <img src="images/review-1.png" class="user" alt="">
            <h3>Sara</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
        </div>

        <div class="box">
            <img src="images/quote-img.png" alt="" class="quote">
            <p>الخدمة رائعة إلى أبعد حد
                جيتهم يوم الجمعة دايم ضغط وزحمة ومع ذلك نفسيتهم زينة وخدمتهم نظيفة
                دايمًا كل ما أروح صالون افتقد إني أروق وأسترخي، عدا عند شيك فعلاً روقان وبخور ووجوه بشوشة بالذات بشرى!
                أول مرة أزورهم والأكيد إني ماعاد باروح لغيرهم! ❤️
                العاملة الي سويت عندها بديكير اسمعها كورا انصح فيها 👍🏻.</p>
            <img src="images/review-2.png" class="user" alt="">
            <h3>Tahani A.H</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
        </div>
        
        <div class="box">
            <img src="images/quote-img.png" alt="" class="quote">
            <p>صالون احترافي وجميل وشرح ونظيف وخدمه عشره من عشره الصراحه شيء راقي من زمان نبي اماكن راقيه وتدخلين تسوين الخدمه وتطلعين بلا انتظار   🏻 خدمتهم حلوه وريحه المكان حلوه وموظفه الاستقبال تهببببل ❤️‍🔥❤️‍🔥سويت عندهم عنايه بالاظافر وقص وكلهم نفس ما ابي واحسن يحتاج تاخذين موعد وفيه ضيافه قهوه ومويه ♥️♥️.</p>
            <img src="images/review-3.png" class="user" alt="">
            <h3>Wessam Ali</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
        </div>

    </div>

</section>

<!-- reviews end -->

<!-- footer -->

<section class="footer">

    <div class="box-container">
 
       <div class="box">
        <h3> مواقع التواصل الإجتماعي </h3>
        <!--<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis quos</p>-->
        <div class="share">
        <a href="#" class="fab fa-facebook-f"></a>
             <a href="#" class="fab fa-twitter"></a>
             <a href="#" class="fab fa-instagram"></a>
             <a href="#" class="fab fa-linkedin"></a>
        </div>
    </div>   
    
    <div class="box">
       <h3>للتواصل معنا</h3>
       
       <h5>عنيزة</h5>
       <p>+966 535088855</p>
      <h5>بريدة</h5>
       <p>+966 534788866</p>
       <h5>الرس</h5>
       <p>+966 537808855</p>

       <h3>مواقعنا</h3>
       <p>صالون شيك <br>
        المملكة العربية السعودية</p>
    </div>
<div class="credit">credit by<span> studens iau</span>| all rights reserved!</div> 
</div>
 </section>





<!-- footer end-->







<script src="js/script.js"></script>

</body>
</html>