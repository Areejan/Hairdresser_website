<?php
include_once('connt.php');

// Fetch services with the "Hairstyle" category
$sql = "SELECT * FROM serves WHERE Category = 'Hairstyle'";
$result = $conn->query($sql);

$services = array();

if ($result->num_rows > 0) {
    // Fetching data and storing in array
    while($row = $result->fetch_assoc()) {
        $service = array(
            "Name" => $row["Name"],
            "Price" => $row["Price"]
        );
        array_push($services, $service);
    }
}

// Close database connection
$conn->close();

// Output services as JSON
header('Content-Type: application/json');
echo json_encode($services);
?>
