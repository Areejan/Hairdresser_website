<?php
session_start();
include_once('connt.php');

$data = json_decode(file_get_contents("php://input"), true);

// Assuming the customer ID is stored in session as $_SESSION['customerID']
$customerID = $_SESSION['customerID'];
$appointmentDate = $data['appointmentDate'];
$appointmentTime = $data['appointmentTime'];
$branch = $data['branch'];
$services = $data['services'];

$response = [];

// Begin transaction
$conn->begin_transaction();

try {
    // Insert the appointment
    $stmt = $conn->prepare("INSERT INTO Appointments (CustomerID, EmployeeID, AppointmentTime, Branch) VALUES (?, NULL, ?, ?)");
    $appointmentDateTime = $appointmentDate . ' ' . $appointmentTime;
    $stmt->bind_param("iss", $customerID, $appointmentDateTime, $branch);
    $stmt->execute();
    $appointmentID = $conn->insert_id;

    // Insert services
    foreach ($services as $service) {
        $stmt = $conn->prepare("INSERT INTO AppointmentServices (AppointmentID, ServiceID) VALUES (?, ?)");
        $stmt->bind_param("ii", $appointmentID, $service);
        $stmt->execute();
    }

    // Commit transaction
    $conn->commit();
    $response['message'] = "Appointment saved successfully!";
} catch (Exception $e) {
    $conn->rollback();
    $response['message'] = "Error: " . $e->getMessage();
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>
