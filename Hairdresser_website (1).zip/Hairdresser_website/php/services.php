<?php
// Database connection
include_once('connt.php');

// Extract category from GET parameters
$category = $_GET['category'];


// Fetch services based on the provided category
$sql = "SELECT * FROM Serves WHERE Category = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $category);
$stmt->execute();
$result = $stmt->get_result();

$services = array();

if ($result->num_rows > 0) {
    // Fetching data and storing in array
    while($row = $result->fetch_assoc()) {
        $service = array(
            "ID" => $row["ServesID"],
            "Name" => $row["Name"],
            "Price" => $row["Price"]
        );
        array_push($services, $service);
    }
}

// Close database connection
$stmt->close();
$conn->close();

// Output services as JSON
header('Content-Type: application/json');
echo json_encode($services);
?>
