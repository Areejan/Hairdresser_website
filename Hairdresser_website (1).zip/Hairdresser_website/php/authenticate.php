<?php
// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    include_once('connt.php');

    // Escape user inputs for security
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    // SQL query to check if the email and password match
    $sql = "SELECT CustomerID, CEmail FROM Customer WHERE CEmail = '$email' AND CPassword = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // User authenticated, set session variables
        $_SESSION['email'] = $row['CEmail'];
        $_SESSION['customerID'] = $row['CustomerID']; // Store customer ID in the session

        // Redirect to the service page
        header("Location: ../index.php");
        exit;
    } else {
        // Invalid credentials, redirect back to the sign-in page
        header("Location: ../signup.html");
        exit;
    }


} else {
    // If the form is not submitted, redirect back to the sign-in page
    header("Location: ../signup.html");
    exit;
}
?>
