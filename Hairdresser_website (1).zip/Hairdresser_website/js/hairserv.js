$(document).ready(function () {
    // AJAX request to fetch services when the document is ready
    $.ajax({
      type: "GET",
      url: "php/fetch_hairstyle_services.php",
      dataType: "json",
      success: function (data) {
        populateServices(data);
      },
      error: function (xhr, status, error) {
        console.error("Error fetching services: ", error);
      },
    });
  
    // Function to populate services dynamically
    function populateServices(services) {
      var serviceCheckboxes = $("#serviceCheckboxes");
      serviceCheckboxes.empty(); // Clear existing checkboxes
  
      services.forEach(function (service) {
        var checkbox = $("<input>").attr({
          type: "checkbox",
          id: service.Name.replace(/\s/g, ""),
          name: "services[]",
          value: service.Name,
        });
        var label = $("<label>")
          .attr("for", service.Name.replace(/\s/g, ""))
          .text(service.Name + " " + service.Price + " ﷼")
          .append("<br>");
        serviceCheckboxes.append(checkbox);
        serviceCheckboxes.append(label);
      });
    }
  });
  