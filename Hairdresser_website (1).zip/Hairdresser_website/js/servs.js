$(document).ready(function () {
  // Extract category name from each form with class 'categoryForm'
  $(".categoryForm").each(function () {
    var category = $(this).attr("id");

    // AJAX request to fetch services for each category
    $.ajax({
      type: "GET",
      url: "php/services.php?category=" + category,
      dataType: "json",
      success: function (data) {
        populateServices(data);
      },
      error: function (xhr, status, error) {
        console.error("Error fetching services: ", error);
      },
    });
  });

  // Function to populate services dynamically
  function populateServices(services) {
    var serviceCheckboxes = $("#serviceCheckboxes");
    serviceCheckboxes.empty(); // Clear existing checkboxes

    services.forEach(function (service) {
      var checkbox = $("<input>").attr({
        type: "checkbox",
        id: "service" + service.ID, // Use service ID to ensure unique IDs
        name: "services[]",
        value: service.ID, // Use service ID as value
      });
      var label = $("<label>")
        .attr("for", "service" + service.ID) // Ensure the 'for' attribute matches the input ID
        .text(service.Name + " " + service.Price + " ﷼")
        .append("<br>");
      serviceCheckboxes.append(checkbox);
      serviceCheckboxes.append(label);
    });
  }

  $('#submitBtn').click(function(e) {
    e.preventDefault(); // Prevent default form submission

    var formData = {
        'appointmentDate': $('#appointmentDate').val(),
        'appointmentTime': $('#appointmentTime').val(),
        'branch': $('#branch').val(),
        'services': []
    };

    // Gather all checked services by their IDs
    $('input[name="services[]"]:checked').each(function() {
        formData.services.push(parseInt($(this).val())); // Collects service IDs
    });

    // AJAX request to submit the form
    $.ajax({
        type: 'POST',
        url: 'php/save_appointment.php',
        data: JSON.stringify(formData),
        contentType: 'application/json',
        success: function(response) {
            alert('Appointment Saved Successfully' );
            window.location.href = 'index.php';
        },
        error: function(xhr, status, error) {
            alert('Error saving appointment: ' + error);
        }
    });
});
});
