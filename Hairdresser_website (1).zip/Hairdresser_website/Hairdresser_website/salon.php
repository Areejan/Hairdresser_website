<?php

// Database connection settings
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root"; // Change this to your MySQL username
$password = " "; // Change this to your MySQL password
$database = "salon_database"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the Appointments table
$sql = "SELECT AppointmentID, CustomerID, EmployeeID, ServiceID, AppointmentTime, Branch FROM Appointments";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "Appointment ID: " . $row["AppointmentID"] . "<br>";
        echo "Customer ID: " . $row["CustomerID"] . "<br>";
        echo "Employee ID: " . $row["EmployeeID"] . "<br>";
        echo "Service ID: " . $row["ServiceID"] . "<br>";
        echo "Appointment Time: " . $row["AppointmentTime"] . "<br>";
        echo "Branch: " . $row["Branch"] . "<br>";
        echo "<br>";
    }
} else {
    echo "0 results";
}

// Close connection
$conn->close();

?>