CREATE DATABASE salon_database;

USE salon_database;

-- Customer Table
CREATE TABLE Customer (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    CFName VARCHAR(100),
    CLName VARCHAR(100),
    CEmail VARCHAR(100) UNIQUE,
    CPhone VARCHAR(20) UNIQUE,
    CDateOfBirth DATE,
    CPassword VARCHAR(255)
);

-- Employee Table
CREATE TABLE Employees (
    EmployeeID DECIMAL(6,0) NOT NULL PRIMARY KEY,
    FirstName VARCHAR(20) NOT NULL,
    LastName VARCHAR(25) NOT NULL,
    Email VARCHAR(25) NOT NULL UNIQUE,
    PhoneNumber DECIMAL(20) NOT NULL UNIQUE
);

-- Services Table
CREATE TABLE Serves (
    ServesID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50),
    Price DECIMAL(10, 2)
);
-- Appointments Table
CREATE TABLE Appointments (
    AppointmentID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT,
    EmployeeID DECIMAL(6, 0),
    ServiceID INT,
    AppointmentTime DATETIME,
    Branch ENUM('Burydah', 'Unaizah', 'Alrrass'),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID),
    FOREIGN KEY (ServiceID) REFERENCES Serves(ServesID)
);

INSERT INTO Employees
 VALUES(01,"Amal","Aldosari","Amal2@gmail.com",0504489782);
INSERT INTO Employees
 VALUES(02,"Maha","Alahmari","Maha5@gmail.com",0507833442),
 (03,"Lama","Alotaibi","Lam13@gmail.com",0502234445),
 (04,"Sara","Aldosari","Sara22@gmail.com",0502236777),
 (05,"Renad","Almajed","Ren34@gmail.com",0554423890),
 (06,"Atheer","Alotaibi","Atheer7@gmail.com",0507784566),
 (07,"Reem","Aldosari","Reem9@gmail.com",0537789906),
 (08,"Sama","Alhabib","Sama66@gmail.com",0500678885),
 (09,"Layan","Alonazy","Layan3@gmail.com",0504422223),
 (10,"Rand","Alqhtani","Rand@gmail.com",0503333782),
 (11,"Mashel","Alajmi","Mashel@gmail.com",0502222282),
 (12,"Haya","Aldosari","Haya4@gmail.com",05044844444),
 (13,"Asrar","Alanazy","Asrar2@gmail.com",0502234449),
 (14,"Layan","Alrabbea","Layan1@gmail.com",0500022399),
 (15,"Najed","Alshahrani","Najed@gmail.com",0550999444);
 
 insert into serves values 
-- قص و تصفيف الشعر
(1,"قص الشعر",46),
(2,"قص الشعر بوي",69 ),
(3,"استشوار",79),
(4,"ويفي شعر",172),
(5,"تساريح شعر لجميع انواع الشعر",230),
-- عناية و معالجة العشر
(6,"غسيل الشعر",18),
(7,"حمام الزيت",69),
(8,"حمام زيت فيتامينات",98),
(9,"ديتوكس فروة الشعر",159),
(10,"معالج بروتين (تقنية النانو) لجميع اطوال الشعر",980),
-- صبغات الشعر
(11,"اختيار سحب لون",49),
(12,"صبغ جذور",115),
(13,"تصحيح لون الشعر",115),
(14,"صبغة لون واحد (بدون سحب لون)",590),
(15,"صبغة هايلايت \ اومبريه لجميع اطوال الشعر",890),
-- الوجه و الجسم
(16,"فتلة حواجب",46),
(17,"تشقير حواجب (بدون صبغة)",46),
(18,"تشقير حواجب (مع صبغة)",57),
(19,"تنظيف بشرة عميق",189),
(20,"فتلة \ شمع شارب",23),
(21,"فتلة \ شمع رقبة",34),
(22,"فتلة \ شمع وجه",57),
(23,"شمع تحت الذراعين",23),
(24,"شمع نصف الايدي \ الارجل",46),
(25,"شمع كامل الايدي \ الارجل",92),
(26,"شمع ظهر \ بطن",69),
-- الاظافر
(27,"قص و برد الاظافر",42),
(28,"تركيب اظافر",70),
(29,"عناية بالايدي (مناكير)",85),
(30,"عناية بالارجل (بديكير)",85),
(31,"طلاء اظافر",12),
(32,"طلاء اظافر فرنسي",35),
(33,"اومبريه اظافر",59 ),
(34,"ازالة طلاء الاظافر",5 ),
-- ميك اب
(35,"ميك اب (بدون تركيب رموش)",250),
(36,"ميك اب (مع تركيب رموش)",290),
(37,"تركيب رموش",57),
-- استرخاء
(38,"مساج سويدي (مدة ساعة)",190),
(39,"حمام مغربي (شامل حمام زيت للشعر)",290);

 
INSERT INTO Customer  VALUES
( 01,"Areej", "Mohammed","areej.hajji@gmail.com",0541205211,"2001-02-17", "1234"),
( 02,"Maria","Ali","Maria2@gmail.com",0567438821,"1996-08-23", "6758"),
( 03,"Alia","Bader", "Alia88@gmail.com",0543879213,"1987-12-07", "1111"),
( 04,"Shatha","Hamad", "Shatha8@gmail.com",0533886721,"2000-11-04", "5467"),
( 05,"Dalia","Sari", "Dalia3@gmail.com",0567234598,"1995-08-16", "9873"),
(06, "Lamia","Ahmed", "Lamia66@gmail.com",0560452113,"2000-09-04", "8834"),
(07,"Aryam","Saud", "Aram2@gmail.com",056554389,"2004-01-01", "1189"),
(08,"Shahad","Fahad", "shahad12@gmail.com",0598762344,"1989-02-04", "4472");

INSERT INTO Customer VALUES( 09,"Alia","Saleh","Alia@gmail.com",0543879013,"1987-12-07", "1111"),
(11,"Aram","Aziz", "Aram@gmail.com",056554189,"2004-01-01", "1189"),
(10,"Lama","Saad", "Lama@gmail.com",0560452213,"2000-09-04", "8834"),
(12,"Danah","Adeeb", "Danah99@gmail.com",0564234498,"1995-09-16", "3422"),
(13,"Shahha","Salem", "Shahha@gmail.com",0533926721,"1999-09-01","5467");

INSERT INTO Appointments VALUES
  (01,1, 4, 2, '2024-03-17 09:00:00', 'Burydah');
 INSERT INTO Appointments VALUES (02, 3, 6, 1, '2024-03-17 10:30:00','Burydah'),
  (03,2, 8, 3, '2024-03-17 12:00:00', 'Burydah'),
  (04,5, 11, 2, '2024-03-17 14:30:00', 'Unaizah'),
  (05,4, 1, 3, '2024-03-17 16:00:00', 'Unaizah'),
  (06,3, 5, 1, '2024-03-18 10:00:00', 'Unaizah'),
  (07,2, 9, 2, '2024-03-18 11:30:00', 'Alrrass'),
  (08,1, 13, 3, '2024-03-18 13:00:00', 'Alrrass'),
  (09,5, 2, 1, '2024-03-18 15:30:00', 'Alrrass'),
  (10,4, 7, 2, '2024-03-18 17:00:00','Burydah' ),
  (11,3, 10, 3, '2024-03-19 09:30:00', 'Burydah'),
  (12,2, 12, 1, '2024-03-19 11:00:00','Unaizah' ),
  (13,1, 14, 2, '2024-03-19 12:30:00', 'Unaizah'),
  (14,5, 3, 3, '2024-03-19 14:00:00','Alrrass' );

-- Customer information
create view CustomerInfo As 
select * from Customer;

-- Employee information
create view EmployeeInfo As 
Select * from Employees ; 

-- All Servic 
create view allserves As 
Select * from serves;

-- All Appointment
CREATE VIEW allAppointment AS
SELECT a.AppointmentID, c.CFName AS CustomerFirstName, c.CLName AS CustomerLastName
,e.FirstName AS EmployeeFirstName ,e.LastName AS EmployeeLastName
,s.Name AS ServiceName, a.AppointmentTime , a.Branch
FROM Appointments a
JOIN Customer c ON a.CustomerID = c.CustomerID
JOIN Employees e ON a.EmployeeID = e.EmployeeID
JOIN Serves s ON a.ServiceID = s.ServesID;

-- Today Appointment 
CREATE VIEW TodayAppointments AS
SELECT a.AppointmentID, c.CFName AS CustomerFirstName, c.CLName AS CustomerLastName
 ,e.FirstName AS EmployeeFirstName, e.LastName AS EmployeeLastName
 , s.Name AS ServiceName, a.AppointmentTime, a.Branch
FROM Appointments a
JOIN Customer c ON a.CustomerID = c.CustomerID
JOIN Employees e ON a.EmployeeID = e.EmployeeID
JOIN Serves s ON a.ServiceID = s.ServesID
WHERE DATE(a.AppointmentTime) = CURDATE();

-- Upcoming Appointments
CREATE VIEW UpcomingAppointments AS
SELECT a.AppointmentID, c.CFName AS CustomerFirstName, c.CLName AS CustomerLastName
, e.FirstName AS EmployeeFirstName, e.LastName AS EmployeeLastName
, s.Name AS ServiceName, a.AppointmentTime , a.Branch
FROM Appointments a
JOIN Customer c ON a.CustomerID = c.CustomerID
JOIN Employees e ON a.EmployeeID = e.EmployeeID
JOIN Serves s ON a.ServiceID = s.ServesID
WHERE a.AppointmentTime > NOW()
ORDER BY a.AppointmentTime ASC;

-- Range of Service
CREATE VIEW ServicePriceRange AS
SELECT 
    CASE 
        WHEN Price <= 50 THEN 'Under $50'
        WHEN Price <= 100 THEN '$51 - $100'
        WHEN Price <= 150 THEN '$101 - $150'
        ELSE 'Over $150'
    END AS PriceRange,
    COUNT(*) AS Count
FROM Serves
GROUP BY PriceRange;

