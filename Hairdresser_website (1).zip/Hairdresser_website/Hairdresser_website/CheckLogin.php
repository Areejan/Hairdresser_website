<?php 
    if (isset($_POST['Username']) && isset($_POST['password'])) 
    {
        //open database to check the user authentication
                $Query="Select CFName  from Customer where CEmail='" . $_POST['Username']."' and CPassword='".$_POST['password'] ."'";
                if ( !($database=mysqli_connect("localhost","root","")))
                {
                    header('location: index.php?problem=CannotConnectToServer');
                    exit ("couldn't connect to the server");
                }   
                if (!mysqli_select_db ($database,"salon_database"))    
                {
                    header('location: index.php?problem=CannotConnectToDB');
                    exit ("couldn't open the database");
                }
                if (! ($result= mysqli_query (  $database,$Query)))
                {
                    header('location: index.php?problem=Querycouldntbeexecuted');
                    exit(mysqli_error($database));
                }
                mysqli_close($database);    
        if (mysqli_num_rows($result)>0)
        {
            $row=mysqli_fetch_row($result);
            session_start();
            $_SESSION['FullName']=$row[0];
            header('location: html/index.html');
            exit;
        }
        else
        {
            header('location: index.php?problem=ErrorLogin');
            exit;
        }
    }
?>          