<?php
// Database configuration
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "salon_database"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $fname = $_POST['Fname'];
    $lname = $_POST['Lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $dob = $_POST['dob'];
    $password = $_POST['password'];
    
    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO Customer (CFName, CLName, CEmail, CPhone, CDateOfBirth, CPassword) VALUES (?, ?, ?, ?, ?, ?)");
        

    // Execute the statement
    if ($stmt->execute([$fname, $lname, $email, $phone, $dob, $password]) == TRUE) {
        echo "<h2>Registration Successful!</h2> <a href='index.php'>Login</a>";
        header('location: index.php');
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>

