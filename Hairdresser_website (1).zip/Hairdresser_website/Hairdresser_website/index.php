<html>
<head>
<link rel="stylesheet" href="css/index.css">
<?php
//start a session, to check if asession exit.
//if a session exist destroy it when reaching index page(logout) 
//clickong on logut will send to this page 
    session_start();
    if (isset($_SESSION['FullName']))
        {
        $_SESSION = array(); // 
    session_destroy(); // 
    setcookie ('PHPSESSID', '', time()-3600, '/', '', 0, 0);
    }
        include('includes/header.php'); 
?>
</head>
<body>
        <div class="container">
        <section class="home" id="home">

<div class="content">
    <span>أهلا بكم في شيك صالون</span>  
    <h3>أهتمامنا الأول جمالك</h3>

</section>
            <br><br>

            <form  method="post"    action="CheckLogin.php">
                    <?php if (isset ($_GET['problem']) and ($_GET['problem']=='ErrorLogin')) 
                    echo "<label style='color:red;'> Login ERROR: Please check username and/or password </label>"
                    ?>
                    <input type="text" name="Username" placeholder="Username" class="name_label">
                    <br><br>
                    <input type="password" name="password" placeholder="Enter your password here.." class="pass_label">
                    <input type="submit" value="Login">
                    <br>
                    <input  type="checkbox" name="rememberUP"   checked>Remember Me.
                    <a href="resetPassword.html">Forget Password?</a>
                    <a href="signup.html">create an account</a>
                </form>
        </div>
</body>
</html>
<?php include('includes/footer.html'); 
?>          