<?php
// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = " ";
    $dbname = "salon_database";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Escape user inputs for security
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    // SQL query to check if the email and password match
    $sql = "SELECT * FROM Customer WHERE CEmail = '$email' AND CPassword = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User authenticated, set session variables
        $_SESSION['email'] = $email;

        // Redirect to the service page
        header("Location: services.php");
        exit;
    } else {
        // Invalid credentials, redirect back to the sign-in page
        header("Location: signin.html");
        exit;
    }

    // Close the database connection
    $conn->close();
} else {
    // If the form is not submitted, redirect back to the sign-in page
    header("Location: signin.html");
    exit;
}
?>