<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the rating and review fields are set and not empty
    if (isset($_POST["rating"]) && isset($_POST["review"]) && !empty($_POST["rating"]) && !empty($_POST["review"])) {
        // Sanitize and store the submitted data
        $rating = htmlspecialchars($_POST["rating"]);
        $review = htmlspecialchars($_POST["review"]);

        // Here you can perform further actions, such as storing the review in a database

        // For demonstration purposes, let's simply display the submitted data
        echo "Rating: $rating<br>";
        echo "Review: $review<br>";
        echo "Thank you for your review!";
    } else {
        // Handle the case where required fields are missing
        echo "Error: Rating and review are required!";
    }
} else {
    // Handle the case where the form is not submitted
    echo "Error: Form not submitted!";
}
?>