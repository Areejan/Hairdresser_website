<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHIC SALON</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- header -->
    <section class="header">

        <a href="#" class="logo"> CHIC SALON </a>
     
        <a href="#" class="logo">صالون شيك</a>
        <nav class="navbar">
            <div id="close-navbar" class="fas fa-time"></div>
            <a href="#home">الرئيسية</a>
            <a href="#login">تسجيل الدخول</a>
            <a href="#about">عنا</a>
            <a href="#services">خدماتنا</a>
            <a href="#Visit">احجز الآن</a>
            <a href="#review">ارائكم عنا</a>
            <a href="#footer">تواصلوا معنا</a>
            
        </nav>
     
        <div id="menu-btn" class="fas fa-bars"></div>
     
     </section>
<!-- header -->