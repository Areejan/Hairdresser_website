-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2024 at 03:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salon_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `email`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Stand-in structure for view `allappointment`
-- (See below for the actual view)
--
CREATE TABLE `allappointment` (
`AppointmentID` int(11)
,`CustomerFirstName` varchar(100)
,`CustomerLastName` varchar(100)
,`EmployeeFirstName` varchar(20)
,`EmployeeLastName` varchar(25)
,`ServiceName` varchar(50)
,`AppointmentTime` datetime
,`Branch` enum('Burydah','Unaizah','Alrrass')
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `allserves`
-- (See below for the actual view)
--
CREATE TABLE `allserves` (
`ServesID` int(11)
,`Name` varchar(50)
,`Price` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `AppointmentID` int(11) NOT NULL,
  `CustomerID` int(11) DEFAULT NULL,
  `EmployeeID` decimal(6,0) DEFAULT NULL,
  `ServiceID` int(11) DEFAULT NULL,
  `AppointmentTime` datetime DEFAULT NULL,
  `Branch` enum('Burydah','Unaizah','Alrrass') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointmentservices`
--

CREATE TABLE `appointmentservices` (
  `id` int(11) NOT NULL,
  `AppointmentID` int(11) NOT NULL,
  `ServiceID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustomerID` int(11) NOT NULL,
  `CFName` varchar(100) DEFAULT NULL,
  `CLName` varchar(100) DEFAULT NULL,
  `CEmail` varchar(100) DEFAULT NULL,
  `CPhone` varchar(20) DEFAULT NULL,
  `CDateOfBirth` date DEFAULT NULL,
  `CPassword` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `CFName`, `CLName`, `CEmail`, `CPhone`, `CDateOfBirth`, `CPassword`) VALUES
(1, 'Areej', 'Mohammed', 'areej.hajji@gmail.com', '541205211', '2001-02-17', '1234'),
(2, 'Maria', 'Ali', 'Maria2@gmail.com', '567438821', '1996-08-23', '6758'),
(3, 'Alia', 'Bader', 'Alia88@gmail.com', '543879213', '1987-12-07', '1111'),
(4, 'Shatha', 'Hamad', 'Shatha8@gmail.com', '533886721', '2000-11-04', '5467'),
(5, 'Dalia', 'Sari', 'Dalia3@gmail.com', '567234598', '1995-08-16', '9873'),
(6, 'Lamia', 'Ahmed', 'Lamia66@gmail.com', '560452113', '2000-09-04', '8834'),
(7, 'Aryam', 'Saud', 'Aram2@gmail.com', '56554389', '2004-01-01', '1189'),
(8, 'Shahad', 'Fahad', 'shahad12@gmail.com', '598762344', '1989-02-04', '4472'),
(9, 'Alia', 'Saleh', 'Alia@gmail.com', '543879013', '1987-12-07', '1111'),
(10, 'Lama', 'Saad', 'Lama@gmail.com', '560452213', '2000-09-04', '8834'),
(11, 'Aram', 'Aziz', 'Aram@gmail.com', '56554189', '2004-01-01', '1189'),
(12, 'Danah', 'Adeeb', 'Danah99@gmail.com', '564234498', '1995-09-16', '3422'),
(13, 'Shahha', 'Salem', 'Shahha@gmail.com', '533926721', '1999-09-01', '5467');

-- --------------------------------------------------------

--
-- Stand-in structure for view `customerinfo`
-- (See below for the actual view)
--
CREATE TABLE `customerinfo` (
`CustomerID` int(11)
,`CFName` varchar(100)
,`CLName` varchar(100)
,`CEmail` varchar(100)
,`CPhone` varchar(20)
,`CDateOfBirth` date
,`CPassword` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `employeeinfo`
-- (See below for the actual view)
--
CREATE TABLE `employeeinfo` (
`EmployeeID` int(11)
,`FirstName` varchar(20)
,`LastName` varchar(25)
,`Email` varchar(25)
,`PhoneNumber` decimal(20,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `EmployeeID` int(11) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(25) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `PhoneNumber` decimal(20,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`EmployeeID`, `FirstName`, `LastName`, `Email`, `PhoneNumber`) VALUES
(1, 'Amal', 'Aldosari', 'Amal2@gmail.com', 504489782),
(2, 'Maha', 'Alahmari', 'Maha5@gmail.com', 507833442),
(3, 'Lama', 'Alotaibi', 'Lam13@gmail.com', 502234445),
(4, 'Sara', 'Aldosari', 'Sara22@gmail.com', 502236777),
(5, 'Renad', 'Almajed', 'Ren34@gmail.com', 554423890),
(6, 'Atheer', 'Alotaibi', 'Atheer7@gmail.com', 507784566),
(7, 'Reem', 'Aldosari', 'Reem9@gmail.com', 537789906),
(8, 'Sama', 'Alhabib', 'Sama66@gmail.com', 500678885),
(9, 'Layan', 'Alonazy', 'Layan3@gmail.com', 504422223),
(10, 'Rand', 'Alqhtani', 'Rand@gmail.com', 503333782),
(11, 'Mashel', 'Alajmi', 'Mashel@gmail.com', 502222282),
(12, 'Haya', 'Aldosari', 'Haya4@gmail.com', 5044844444),
(13, 'Asrar', 'Alanazy', 'Asrar2@gmail.com', 502234449),
(14, 'Layan', 'Alrabbea', 'Layan1@gmail.com', 500022399),
(15, 'Najed', 'Alshahrani', 'Najed@gmail.com', 550999444),

-- --------------------------------------------------------

--
-- Table structure for table `serves`
--

CREATE TABLE `serves` (
  `ServesID` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `Category` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `serves`
--

INSERT INTO `serves` (`ServesID`, `Name`, `Price`, `Category`) VALUES
(1, 'قص الشعر', 46.00, 'Haircut'),
(2, 'قص الشعر بوي', 69.00, 'Haircut'),
(3, 'استشوار', 79.00, 'Hairstyle'),
(4, 'ويفي شعر', 172.00, 'Hairstyle'),
(5, 'تساريح شعر لجميع انواع الشعر', 230.00, 'Hairstyle'),
(6, 'غسيل الشعر', 18.00, 'Hairstyle'),
(7, 'حمام الزيت', 69.00, 'Hairstyle'),
(8, 'حمام زيت فيتامينات', 98.00, 'Hairstyle'),
(9, 'ديتوكس فروة الشعر', 159.00, 'Hairstyle'),
(10, 'معالج بروتين (تقنية النانو) لجميع اطوال الشعر', 980.00, 'Hairstyle'),
(11, 'اختيار سحب لون', 49.00, 'Hairstyle'),
(12, 'صبغ جذور', 115.00, 'Hairstyle'),
(13, 'تصحيح لون الشعر', 115.00, 'Hairstyle'),
(14, 'صبغة لون واحد (بدون سحب لون)', 590.00, 'Hairstyle'),
(15, 'صبغة هايلايت  اومبريه لجميع اطوال الشعر', 890.00, 'Hairstyle'),
(16, 'فتلة حواجب', 46.00, 'Eyebrow'),
(17, 'تشقير حواجب (بدون صبغة)', 46.00, 'Eyebrow'),
(18, 'تشقير حواجب (مع صبغة)', 57.00, 'Eyebrow'),
(19, 'تنظيف بشرة عميق', 189.00, 'Eyebrow'),
(20, 'فتلة  شمع شارب', 23.00, 'Eyebrow'),
(21, 'فتلة  شمع رقبة', 34.00, 'Eyebrow'),
(22, 'فتلة  شمع وجه', 57.00, 'Eyebrow'),
(23, 'شمع تحت الذراعين', 23.00, 'Waxing'),
(24, 'شمع نصف الايدي  الارجل', 46.00, 'Waxing'),
(25, 'شمع كامل الايدي  الارجل', 92.00, 'Waxing'),
(26, 'شمع ظهر  بطن', 69.00, 'Waxing'),
(27, 'قص و برد الاظافر', 42.00, 'Manicure'),
(28, 'تركيب اظافر', 70.00, 'Manicure'),
(29, 'عناية بالايدي (مناكير)', 85.00, 'Manicure'),
(30, 'عناية بالارجل (بديكير)', 85.00, 'Manicure'),
(31, 'طلاء اظافر', 12.00, 'Manicure'),
(32, 'طلاء اظافر فرنسي', 35.00, 'Manicure'),
(33, 'اومبريه اظافر', 59.00, 'Manicure'),
(34, 'ازالة طلاء الاظافر', 5.00, 'Manicure'),
(35, 'ميك اب (بدون تركيب رموش)', 250.00, 'Makeup'),
(36, 'ميك اب (مع تركيب رموش)', 290.00, 'Makeup'),
(37, 'تركيب رموش', 57.00, 'Makeup'),
(38, 'مساج سويدي (مدة ساعة)', 190.00, 'Relaxation'),
(39, 'حمام مغربي (شامل حمام زيت للشعر)', 290.00, 'Relaxation');

-- --------------------------------------------------------

--
-- Stand-in structure for view `servicepricerange`
-- (See below for the actual view)
--
CREATE TABLE `servicepricerange` (
`PriceRange` varchar(11)
,`Count` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `todayappointments`
-- (See below for the actual view)
--
CREATE TABLE `todayappointments` (
`AppointmentID` int(11)
,`CustomerFirstName` varchar(100)
,`CustomerLastName` varchar(100)
,`EmployeeFirstName` varchar(20)
,`EmployeeLastName` varchar(25)
,`ServiceName` varchar(50)
,`AppointmentTime` datetime
,`Branch` enum('Burydah','Unaizah','Alrrass')
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `upcomingappointments`
-- (See below for the actual view)
--
CREATE TABLE `upcomingappointments` (
`AppointmentID` int(11)
,`CustomerFirstName` varchar(100)
,`CustomerLastName` varchar(100)
,`EmployeeFirstName` varchar(20)
,`EmployeeLastName` varchar(25)
,`ServiceName` varchar(50)
,`AppointmentTime` datetime
,`Branch` enum('Burydah','Unaizah','Alrrass')
);

-- --------------------------------------------------------

--
-- Structure for view `allappointment`
--
DROP TABLE IF EXISTS `allappointment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allappointment`  AS SELECT `a`.`AppointmentID` AS `AppointmentID`, `c`.`CFName` AS `CustomerFirstName`, `c`.`CLName` AS `CustomerLastName`, `e`.`FirstName` AS `EmployeeFirstName`, `e`.`LastName` AS `EmployeeLastName`, `s`.`Name` AS `ServiceName`, `a`.`AppointmentTime` AS `AppointmentTime`, `a`.`Branch` AS `Branch` FROM (((`appointments` `a` join `customer` `c` on(`a`.`CustomerID` = `c`.`CustomerID`)) join `employees` `e` on(`a`.`EmployeeID` = `e`.`EmployeeID`)) join `serves` `s` on(`a`.`ServiceID` = `s`.`ServesID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `allserves`
--
DROP TABLE IF EXISTS `allserves`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allserves`  AS SELECT `serves`.`ServesID` AS `ServesID`, `serves`.`Name` AS `Name`, `serves`.`Price` AS `Price` FROM `serves` ;

-- --------------------------------------------------------

--
-- Structure for view `customerinfo`
--
DROP TABLE IF EXISTS `customerinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customerinfo`  AS SELECT `customer`.`CustomerID` AS `CustomerID`, `customer`.`CFName` AS `CFName`, `customer`.`CLName` AS `CLName`, `customer`.`CEmail` AS `CEmail`, `customer`.`CPhone` AS `CPhone`, `customer`.`CDateOfBirth` AS `CDateOfBirth`, `customer`.`CPassword` AS `CPassword` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `employeeinfo`
--
DROP TABLE IF EXISTS `employeeinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employeeinfo`  AS SELECT `employees`.`EmployeeID` AS `EmployeeID`, `employees`.`FirstName` AS `FirstName`, `employees`.`LastName` AS `LastName`, `employees`.`Email` AS `Email`, `employees`.`PhoneNumber` AS `PhoneNumber` FROM `employees` ;

-- --------------------------------------------------------

--
-- Structure for view `servicepricerange`
--
DROP TABLE IF EXISTS `servicepricerange`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `servicepricerange`  AS SELECT CASE WHEN `serves`.`Price` <= 50 THEN 'Under $50' WHEN `serves`.`Price` <= 100 THEN '$51 - $100' WHEN `serves`.`Price` <= 150 THEN '$101 - $150' ELSE 'Over $150' END AS `PriceRange`, count(0) AS `Count` FROM `serves` GROUP BY CASE WHEN `serves`.`Price` <= 50 THEN 'Under $50' WHEN `serves`.`Price` <= 100 THEN '$51 - $100' WHEN `serves`.`Price` <= 150 THEN '$101 - $150' ELSE 'Over $150' END ;

-- --------------------------------------------------------

--
-- Structure for view `todayappointments`
--
DROP TABLE IF EXISTS `todayappointments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `todayappointments`  AS SELECT `a`.`AppointmentID` AS `AppointmentID`, `c`.`CFName` AS `CustomerFirstName`, `c`.`CLName` AS `CustomerLastName`, `e`.`FirstName` AS `EmployeeFirstName`, `e`.`LastName` AS `EmployeeLastName`, `s`.`Name` AS `ServiceName`, `a`.`AppointmentTime` AS `AppointmentTime`, `a`.`Branch` AS `Branch` FROM (((`appointments` `a` join `customer` `c` on(`a`.`CustomerID` = `c`.`CustomerID`)) join `employees` `e` on(`a`.`EmployeeID` = `e`.`EmployeeID`)) join `serves` `s` on(`a`.`ServiceID` = `s`.`ServesID`)) WHERE cast(`a`.`AppointmentTime` as date) = curdate() ;

-- --------------------------------------------------------

--
-- Structure for view `upcomingappointments`
--
DROP TABLE IF EXISTS `upcomingappointments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `upcomingappointments`  AS SELECT `a`.`AppointmentID` AS `AppointmentID`, `c`.`CFName` AS `CustomerFirstName`, `c`.`CLName` AS `CustomerLastName`, `e`.`FirstName` AS `EmployeeFirstName`, `e`.`LastName` AS `EmployeeLastName`, `s`.`Name` AS `ServiceName`, `a`.`AppointmentTime` AS `AppointmentTime`, `a`.`Branch` AS `Branch` FROM (((`appointments` `a` join `customer` `c` on(`a`.`CustomerID` = `c`.`CustomerID`)) join `employees` `e` on(`a`.`EmployeeID` = `e`.`EmployeeID`)) join `serves` `s` on(`a`.`ServiceID` = `s`.`ServesID`)) WHERE `a`.`AppointmentTime` > current_timestamp() ORDER BY `a`.`AppointmentTime` ASC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`AppointmentID`),
  ADD KEY `CustomerID` (`CustomerID`);

--
-- Indexes for table `appointmentservices`
--
ALTER TABLE `appointmentservices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustomerID`),
  ADD UNIQUE KEY `CEmail` (`CEmail`),
  ADD UNIQUE KEY `CPhone` (`CPhone`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`EmployeeID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `PhoneNumber` (`PhoneNumber`);

--
-- Indexes for table `serves`
--
ALTER TABLE `serves`
  ADD PRIMARY KEY (`ServesID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `AppointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `appointmentservices`
--
ALTER TABLE `appointmentservices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `EmployeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `serves`
--
ALTER TABLE `serves`
  MODIFY `ServesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`CustomerID`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`),
  ADD CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`ServiceID`) REFERENCES `serves` (`ServesID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
